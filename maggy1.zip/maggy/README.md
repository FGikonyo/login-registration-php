# go to your phpmyadmin and go to import section
# browse for the database.sql file 
#down on the page you will see the import botton 
#After you have imported the database that when it shall work
 hope everything goes well if you got a problem reach me for help 
